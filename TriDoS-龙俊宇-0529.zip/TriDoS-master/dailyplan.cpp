#include "dailyplan.h"
#include "ui_dailyplan.h"
#include "pomodorowidget.h"
#include <QDateTime>
#include <QString>
//更新不同的事件，点击显示细节，点击修改计划(返回事件名字Qstring作为索引),默认显示当天,看不同日子的计划只需要切换不同的dailyplan
//加一个属性描述，完成情况的layout，给事件列表改成滚屏，习惯打卡事件储存（静态向量、录入函数）
//给几个按钮加一下信号槽(今日事:复用一下longtermproject,(delete,modify)：对接longterm，返回字符串作为索引)
//事件的当日完成情况在本类中更改，编辑事件（题目，详情，事件，类型）未提供更改，完成情况的数值
Issue::Issue(QWidget *parent, QString _Title, QString _Detail, QDateTime _Start, QDateTime _End, QString _Kind, Qt::CheckState _Finished)
    :QPushButton(parent)
    ,IssueTitle(_Title)
    ,IssueStart(_Start)
    ,IssueEnd(_End)
    ,IssueDetial(("\t"+_Detail))
    ,IssueFinished(_Finished)
    ,IssueKind(_Kind)
{
    connect(this,&QPushButton::clicked,this,&Issue::Emit_Issue);
    this->setText(IssueTitle);
}
Issue::~Issue(){

}
void Issue::Emit_Issue(){
    emit this->Show_Issue(this);
}
QString Issue::Get_Title(){
    return this->IssueTitle;
}
QString Issue::Get_Dura(){
    QString tmp="";
    tmp=this->IssueStart.toString("yyyy-MM-dd hh:mm:ss");
    tmp+="---";
    tmp+=this->IssueEnd.toString("yyyy-MM-dd hh:mm::ss");
    return tmp;
}
QString Issue::Get_Detail(){
    return this->IssueDetial;
}
QString Issue::Get_Kind(){
    return this->IssueKind;
}
Qt::CheckState Issue::Get_State(){
    return this->IssueFinished;
}
void Issue::Set_State(const Qt::CheckState ck){
    this->IssueFinished=ck;
    return;
}


DailyPlan::DailyPlan(QWidget *parent,QString _Date)
    : QWidget(parent)
    , ui(new Ui::DailyPlan)
    ,Date(_Date)
{
    //init
    ui->setupUi(this);
    IssueOnShow="";
    ui->IssueTitle->setText("null");
    ui->IssueDura->setText("null");
    ui->IssueDetail->setText("null");
    ui->DayOnShow->setText(Date);
    ui->Kinds->setText("No Kind");
    ui->checkBox->setCheckState(Qt::Unchecked);
    //QDateTime CurrentTimer=QDateTime::currentDateTime();
    //QString TimeString =
    //StartDTime();
    //connect(ui->StartDTime,&QPushButton::clicked,this,&DailyPlan::StartDTime());
    //this->DTimer = new QTimer(this);

    //start Timer
    DTimer = new QTimer(this);
    connect(DTimer,&QTimer::timeout,this,&DailyPlan::Renew_DTime);
    DTimer->start(1000);

    /*
    ui->ModiIssue->hide();
    ui->IssueDetail->hide();
    ui->IssueTitle->hide();
    ui->IssueDura->hide();
    */
    ScheduleButtons.clear();
    //debug for addissue and scheduleshow
    /*
    ScheduleButtons.push_back(ui->Issue1);
    ScheduleButtons.push_back(ui->Issue2);
    ScheduleButtons.push_back(ui->Issue3);
    ScheduleButtons.push_back(ui->Issue4);
    ScheduleButtons.push_back(ui->Issue5);
    ScheduleButtons.push_back(ui->Issue6);
    */
    Issue* newissue1= new Issue(ui->ScheduleContent,"newissue1","nononono");
    ScheduleButtons.push_back(newissue1);
    connect(newissue1,&Issue::Show_Issue,this,&DailyPlan::Show_Detail);
    Issue* newissue2= new Issue(ui->ScheduleContent,"newissue2","yesyesyes");
    ScheduleButtons.push_back(newissue2);
    connect(newissue2,&Issue::Show_Issue,this,&DailyPlan::Show_Detail);
    Issue* newissue3= new Issue(ui->ScheduleContent,"newissue3","ohhhhhhhh");
    ScheduleButtons.push_back(newissue3);
    connect(newissue3,&Issue::Show_Issue,this,&DailyPlan::Show_Detail);
    Issue* newissue4= new Issue(ui->ScheduleContent,"newissue4","nononono");
    ScheduleButtons.push_back(newissue4);
    connect(newissue4,&Issue::Show_Issue,this,&DailyPlan::Show_Detail);
    Issue* newissue5= new Issue(ui->ScheduleContent,"newissue5","yesyesyes");
    ScheduleButtons.push_back(newissue5);
    connect(newissue5,&Issue::Show_Issue,this,&DailyPlan::Show_Detail);
    Issue* newissue6= new Issue(ui->ScheduleContent,"newissue6","ohhhhhhhh");
    ScheduleButtons.push_back(newissue6);
    connect(newissue6,&Issue::Show_Issue,this,&DailyPlan::Show_Detail);
    Issue* newissue7= new Issue(ui->ScheduleContent,"newissue7","nononono");
    ScheduleButtons.push_back(newissue7);
    connect(newissue7,&Issue::Show_Issue,this,&DailyPlan::Show_Detail);
    Issue* newissue8= new Issue(ui->ScheduleContent,"newissue8","yesyesyes");
    ScheduleButtons.push_back(newissue8);
    connect(newissue8,&Issue::Show_Issue,this,&DailyPlan::Show_Detail);
    Issue* newissue9= new Issue(ui->ScheduleContent,"newissue9","ohhhhhhhh");
    ScheduleButtons.push_back(newissue9);
    connect(newissue9,&Issue::Show_Issue,this,&DailyPlan::Show_Detail);
    //load schedule
    Load_Schedule();
    //enable modify
    connect(ui->ModiIssue,&QPushButton::clicked,this,&DailyPlan::Modi_Issue);
}

DailyPlan::~DailyPlan()
{
    delete ui;
}

void DailyPlan::Renew_DTime()
{
    QDateTime currentDateTime = QDateTime::currentDateTime();
    QTime currentTime=currentDateTime.time();
    int tmpprogress=(currentTime.hour()*60+currentTime.minute())*100/1440;
    QString timeString = currentDateTime.toString("yyyy-MM-dd hh:mm:ss");//时间转字符串
    ui->NowTime->setText(timeString);
    ui->TimeProgress->setValue(tmpprogress);
    //ui->TimeProgress->setTextVisible(false);
}

void DailyPlan::Load_Schedule(){
    //读入当天计划
    //ScheduleButtons.push_back(ui->Issue1);
    //ScheduleButtons.push_back(ui->Issue2);
    //ScheduleButtons.push_back(ui->Issue3);
    //ScheduleButtons.push_back(ui->Issue4);
    //ScheduleButtons.push_back(ui->Issue5);
    //ScheduleButtons.push_back(ui->Issue6);
    //ScheduleButtons.clear();
    QVBoxLayout *ScheduleLayout = new QVBoxLayout();
    int cnt=0;
    for(auto i=ScheduleButtons.begin();i!=ScheduleButtons.end();i++){
        (*i)->setMinimumHeight(30);
        ScheduleLayout->insertWidget(ScheduleLayout->count(), (*i));
        cnt++;
    }
    for(auto i=HabitButtons.begin();i!=HabitButtons.end();i++){
        (*i)->setMinimumHeight(30);
        ScheduleLayout->insertWidget(ScheduleLayout->count(), (*i));
        cnt++;
    }
    ui->ScheduleContent->resize(250,50*cnt);
    ui->ScheduleScroll->widget()->setLayout(ScheduleLayout);
}

void DailyPlan::Add_Issue(Issue* NewIssue){
    ScheduleButtons.push_back(NewIssue);
    connect(NewIssue,&Issue::Show_Issue,this,&DailyPlan::Show_Detail);
}
void DailyPlan::Add_Habit(Issue* NewHabit){
    HabitButtons.push_back(NewHabit);
    connect(NewHabit,&Issue::Show_Issue,this,&DailyPlan::Show_Detail);
}

void DailyPlan::Show_Detail(Issue* Showed){
    ui->IssueTitle->setText(Showed->Get_Title());
    ui->IssueDura->setText(Showed->Get_Dura());
    ui->IssueDetail->setText(Showed->Get_Detail());
    IssueOnShow=Showed->Get_Title();
    ui->Kinds->setText(Showed->Get_Kind());
    ui->checkBox->setCheckState(Showed->Get_State());
}

void DailyPlan::Modi_Issue(){
    if(IssueOnShow!=""){
        emit Modi_Signal(IssueOnShow);
    }
}

void DailyPlan::on_pomodroButton_clicked()
{
    PomodoroWidget *pomodoro = new PomodoroWidget(nullptr);  // nullptr表示无父对象
    pomodoro->setWindowFlags(Qt::Window);
    pomodoro->setWindowTitle("番茄工作钟");
    pomodoro->setAttribute(Qt::WA_DeleteOnClose);  // 关闭时自动删除
    pomodoro->show();
}

void DailyPlan::on_checkBox_checkStateChanged(const Qt::CheckState &arg1)
{
    for(auto i=ScheduleButtons.begin();i!=ScheduleButtons.end();i++){
        if((*i)->text() == IssueOnShow){
            (*i)->Set_State(arg1);
        }
    }
}

